export const initialAuthorisationState = () => ({
  loginLoading: false,
  loginFailure: false,
  loginLoaded: false,
  access_token: ""
});
