import keyMirror from "keymirror";

export const AuthorisationConstants = keyMirror({
  LOGIN: undefined,
  SIGNUP: undefined,
});
