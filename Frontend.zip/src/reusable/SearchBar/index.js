import React from 'react'
import "./SearchBar.scss"


const SearchBar = props => {
    const {className, placeholder, onChange, options, selectedValue} = props;
    return (
        <div className={`search-bar-div ${className}`}>

        </div>
    )
};

export default SearchBar
